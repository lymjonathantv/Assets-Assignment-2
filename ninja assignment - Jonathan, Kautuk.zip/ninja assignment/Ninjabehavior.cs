﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ninjabehavior : MonoBehaviour
{
    Animator anim;
    int jumping = Animator.StringToHash("jumping");
    int attack = Animator.StringToHash("attack");
    int teabagging = Animator.StringToHash("teabagging");
    int running = Animator.StringToHash("running");




    void Start()
    {
        anim = GetComponent<Animator>();
    }
    void Update()
    {
        Movement();

        float move = Input.GetAxis("Horizontal");
        anim.SetFloat("movement", move);

        AnimatorStateInfo stateInfo = anim.GetCurrentAnimatorStateInfo(0);
        if (Input.GetKeyDown(KeyCode.Space))
        {
            anim.SetTrigger(jumping);
        }
        else if (Input.GetKeyUp(KeyCode.Space))
        {
            anim.ResetTrigger(jumping);
        }
        else if (Input.GetKeyDown(KeyCode.C))
        {
            anim.SetTrigger(teabagging);
        }
        else if (Input.GetKeyUp(KeyCode.C))
        {
            anim.ResetTrigger(teabagging);
        }
        else if (Input.GetKeyDown(KeyCode.F))
        {
            anim.SetTrigger(attack);
        }
        else if (Input.GetKeyUp(KeyCode.F))
        {
            anim.ResetTrigger(attack);
        }
        else if (Input.GetKeyDown(KeyCode.R))
        {
            anim.SetTrigger(running);
        }
        else if (Input.GetKeyUp(KeyCode.R))
        {
            anim.ResetTrigger(running);
        }

    }

    void Movement()
    {
        if (Input.GetKey(KeyCode.D))
        {
            transform.Translate(Vector2.right * 3f * Time.deltaTime);
            transform.eulerAngles = new Vector2(0, 0);
        }
        if (Input.GetKey(KeyCode.A))
        {
            transform.Translate(Vector2.left * 3f * Time.deltaTime);
            transform.eulerAngles = new Vector2(0, 0);
        }
        if (Input.GetButtonDown("Jump"))
        {
            transform.Translate(Vector2.up * 10f * Time.deltaTime);
        }
    }
}
